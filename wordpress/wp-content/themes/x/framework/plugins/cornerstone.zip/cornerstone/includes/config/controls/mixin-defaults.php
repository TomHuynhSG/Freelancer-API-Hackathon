<?php

return array(

	'id'               => '',
	'class'            => '',
	'style'            => '',
	'padding'          => array( '0px', '0px', '0px', '0px', 'unlinked' ),
	'visibility'       => array(),
	'text_align'       => '',

	'link_url'         => '#',
	'link_title'       => '',
	'link_new_tab'     => false,

	'border_style'     => 'none',
	'border_color'     => '',
	'border_width'     => array( '1px', '1px', '1px', '1px', 'linked' ),

	'animation_flavor' => 'none',
	'animation_offset' => 50,
	'animation_delay'  => 0
);