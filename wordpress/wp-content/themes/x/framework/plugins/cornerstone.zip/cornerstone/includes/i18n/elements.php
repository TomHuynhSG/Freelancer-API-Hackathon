<?php
return array(

  'undefined-title' => __( 'Undefined Element', 'cornerstone' ),

  'bar-title' => __( 'Bar', 'cornerstone' ),

  'container-title' => __( 'Container', 'cornerstone' ),

);
